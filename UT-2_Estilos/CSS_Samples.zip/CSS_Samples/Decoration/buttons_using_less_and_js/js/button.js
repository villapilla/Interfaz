function gotolink(link) {
    window.location = link;
}

window.onload = function () {
    document.getElementsByName("btnpara")[0].onclick = 
        gotolink.bind(gotolink, "http://lesscss.org");
}
