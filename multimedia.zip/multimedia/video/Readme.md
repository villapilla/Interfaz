#Modificaciones realizadas en el archivo de video:

1.	Se a�aden al principio y al final el logo de la web.
2.	Inicio del video con una transici�n de enrollado de p�gina.
3.	Se a�ade un filtro de secuencia de colores de espectro.
4.	Final del video con transici�n de cortinilla de estrellas 