#Modificaciones en la imagen:

1.	Recorte con mascara de capa la tarjeta gr�fica de la izquierda, 
recorte con lazo poligonal las restantes tarjetas gr�fica, recorte
por color del texto y el logotipo de envidia.

2.	Se borra la tarjeta gr�fica de la izquierda, las restantes tarjetas 
gr�ficas se cambian de posici�n y se les a�ade borde exterior.

3.	Reconstrucci�n del logotipo de nvidia:
	
	*	Se clonan dos trozos de la parte superior y se rotan sobre el eje X.
	*	Se colocan en la posici�n adecuada.
	*	Se utiliza el tamp�n de clonar para rellenar de color la zona de uni�n.
 	*	Se utiliza la herramienta de desenfoque para igualar los colores.


4.	Se cambia el fondo original negro por un motivo abstracto, fusionado con 
un degradado negro-verde.

5.	Se a�ade una imagen recortada en en forma de ovalo y se encaja en el logotipo,
se le da fondo interior y se le resta opacidad para que se fusione ligeramente con el 
fondo.