#Extras:

1.	Se suprime al reproductor de video el boton de pause est�tico, por 
un boton de pause que solo estar� disponible durante la reproducci�n del video, 
sustituyendo al bot�n play.
2.	Se a�ade al reproductor un barra de reproducci�n permitiendo cambiar el
instante de reproducci�n pinchado sobre ella.