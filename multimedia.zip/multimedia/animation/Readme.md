#Realizaci�n de la animaci�n:

	Se utiliza una animaci�n para desarrollar el banner,
a cada imagen se le asigna un keyframe distinto que la transforma:

*	Translaci�n tanto en el eje X como en el Y,para las imagenes publicitarias.
*	Rotanci�n, para las imagenes de las flechas de movimiento.

	La animaci�n tiene una duranci�n de 50s y se realiza en un ciclo infinito.
	